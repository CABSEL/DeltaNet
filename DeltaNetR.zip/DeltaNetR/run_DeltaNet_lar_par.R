
# This is an example R script for running DeltaNet-LAR with parallel computing.
# If you are not faimliar with R, We recommend to run the script using Code > Source (or Ctrl+Shift+S) when using RStudio.
# Please install required packages (doParallel, foreach, lars) before running the script.

library(doParallel)
library(foreach)
library(lars)

rm(list=ls())

#Check a current working directory
if (!(is.element("run_DeltaNet_lar_par.R",list.files()))){ 
  stop("The current working directory is not set correctly.
      \t Please set a working directory where the files are located.
      \t Three options to set a working directory:
      \t 1. Session > Set Working Directory > Choose Directory (Ctrl+Shift+H)
      \t 2. In the Files pane, click [...](Go to Directory) and choose the correct directory, 
      \t    and click [More] and select [Set As Working Directory].
      \t 3. using setwd(\"your_working_directory_path\"). Please refer ?setwd to see more information")
}

wd <- getwd()
##############################################################################
# Loading data
##############################################################################
filepath <- paste(wd,"example_data",sep="/")
GList <- as.matrix(read.table(paste(filepath,"GList.txt",sep="/"), sep="\t"))
sampleList <- as.matrix(read.table(paste(filepath,"sampleList.txt",sep="/"), sep="\t"))
treatmentList <- as.matrix(read.table(paste(filepath,"TreatmentList.txt",sep="/"), sep="\t"))
repList <- as.matrix(read.table(paste(filepath,"repList.txt",sep="/"), sep="\t"))
lfcMat <- read.table(paste(filepath,"ExpressionData.txt",sep="/"), sep = "\t", row.names = GList, col.names = sampleList)
lfcMat <- as.matrix(lfcMat)


##############################################################################
# DeltaNet-LAR implementation
##############################################################################
registerDoParallel(cores = 2)#change number of cores used for parallel computing

deltanet_lar_par <- dget("deltanet_lar_par.R")
getRankMatrix <- dget("getRankMatrix.R")
start <- proc.time()
delta_r <- 0.05
dlar <- deltanet_lar_par(lfcMat,repList,delta_r)
print(proc.time()-start)


#############################################################################
# extracting a gene List for a specific sample/treatment
#############################################################################
ti <- 5 # choose the index of sample/treatment of interest
rankMat <- dlar$R 
numG <- dim(rankMat)[1]
rankedG <- which(rankMat[,ti]<numG)
topG <- as.matrix(GList[rankedG[order(rankMat[rankedG,ti])]])
rownames(topG) <- 1:dim(topG)[1]
colnames(topG) <- treatmentList[ti]
print(topG)
print("Rest of genes predicted zero (no perturbation) are not shown.")
