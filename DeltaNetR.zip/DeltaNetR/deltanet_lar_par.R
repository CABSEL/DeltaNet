function(LFC,replist=NULL,delta_r=NULL){
  
  
  if(is.null(replist)){
    replist <- seq(1,dim(LFC)[2])
  }else if(length(replist)!=dim(LFC)[2]){
    stop("The length of replist should be the same as the number of samples (= the number of columns of LogFC data matrix.)")
  }
  
  if(is.null(delta_r)){
    delta_r <- 0.10 # default value
  }else if(delta_r<0 | delta_r>1){
    stop("The range of delta_r should be between 0 and 1. A value between 0.01 and 0.1 is recommended.")
  }
  
  
  N <- dim(LFC)[1]
  M <- dim(LFC)[2]
  X <- cbind(t(LFC),diag(M))
  grange <- seq(1,N)
  
  print("about to start LAR")
  
  #Input normalization before least angle regression
  normvec <- apply(X,2,sd)*sqrt((M-1))
  Xn <- scale(X,center=TRUE,scale=normvec)
  Cc <- t(scale(t(LFC),scale=FALSE))
  
  
  colNum <- dim(Xn)[2]
  rowNum <- dim(Xn)[1]
  if(rowNum/colNum>10 & colNum<1000){
      useGram=TRUE;
    }else{
      useGram=FALSE;
    }
  
  print("LAR_par started")
  Beta <- foreach (gind=1:length(grange),.combine=cbind,.packages = c("lars"))%dopar% {
    
    cat(sprintf("DeltaNet_lar is running (%d/%d)\n",gind,length(grange)))
    selG <- grange[gind]
    y <- t(t(Cc[selG,]))
    
    #setting the corresponding column of X for a gene as zero  
    #to make zero diagonal entries in A matrix
    temp <- Xn[,selG]
    Xn[,selG] <- 0
    
    
    btot <- lars(Xn,y,type="lar",normalize=FALSE,use.Gram=useGram)$beta 
    Xn[,selG] <- temp
    
    res <- y %*% rep(1,dim(btot)[1]) - (Xn %*% t(btot))
    rss <- colSums(res^2)
    
    if (length(which(rss<delta_r))==0){
      stepN_cut <- dim(btot)[1]
    }else {stepN_cut <- min(which(rss<delta_r))}
    
    r <- solve(diag(normvec))%*%btot[stepN_cut,]
  }
  
  Amatrix <- t(Beta[1:N,])
  Pmatrix <- t(Beta[(N+1):dim(Beta)[1],])
  ave_result <- getRankMatrix(Pmatrix,repList)
  
  print("Calculation is done.")
  dlar <- list(A=Amatrix,P=ave_result$P,R=ave_result$R)
  
  return(dlar)
}