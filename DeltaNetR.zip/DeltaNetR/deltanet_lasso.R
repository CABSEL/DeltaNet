function(LFC,lambda=NULL,kfold=NULL,replist=NULL){
  if(is.null(lambda)|length(lambda)==0){
    lambda <- 10^seq(-0.1,-5,length.out = 100)
  }else if(length(lambda)<2){
    stop("More than one value of lambda is required for glmnet with CV.")
  }
  
  if(is.null(kfold)|length(kfold)==0){
    kfold <- 10
  }else if(kfold%%1!=0|kfold<5){
    stop("kfold should be a natural number more than 5. Default value is 10.")
  }
  
  if(is.null(replist)|length(replist)==0){
    replist <- seq(1,dim(LFC)[2])
  }else if(length(replist)!=dim(LFC)[2]){
    stop("The length of replist should be the same as the number of samples (= the number of columns of LogFC data matrix.)")
  }
  
  N <- dim(LFC)[1]
  M <- dim(LFC)[2]
  
  X <- cbind(t(LFC),diag(M))
  Y <- t(LFC)
  
  #please specify the options you want to change here except for 'exclude'
  opt.intr <- 0
  opt.alpha <- 1
  opt.lambda <- lambda
  options <- list(intr=opt.intr,alpha=opt.alpha,lambda=opt.lambda)
  
  grange <- seq(1,N)
  srange <- seq(0,1,1e-3)
  cat(sprintf("DeltaNet-LASSO is running...(0/%d)\n",length(grange)))
  
  for (gi in seq(1,length(grange))) {
    gs <- grange[gi]
    cat(sprintf("DeltaNet-LASSO is running...(%4d/%d)\n",gi,length(grange)))
    
    y <- Y[,gs]
    options$exclude <- gs
    result <- crossvalidate_glmnet_betaA(X,y,options,kfold)
    if(gi==1){
      beta_res <- t(result$b_tmin)
    }else{
      beta_res <- cbind(beta_res,t(result$b_tmin))
    }
  }
  
  
  Amatrix <- t(beta_res[1:N,])
  Pmatrix <- t(beta_res[(N+1):dim(beta_res)[1],])
  ave_result <- getRankMatrix(Pmatrix,repList)
  
  print("Calculation is done.")
  dlasso <- list(A=Amatrix,P=ave_result$P,R=ave_result$R)
  
  return(dlasso)

}