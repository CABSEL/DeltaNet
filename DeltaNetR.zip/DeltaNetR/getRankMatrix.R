function(Pmatrix,replist){
  
  rankMatrix <- matrix(1*dim(Pmatrix)[1],nrow = dim(Pmatrix)[1],ncol = max(replist)) # rank matrix

  for (i in seq(1,max(replist))) {
    ri <- which(replist==i)
    Psub <- Pmatrix[,ri]
    if(!is.null(dim(Psub))){
      Pave <- apply(Pmatrix[,ri],1,median)
    }else{
      Pave <- Psub
    }
    sorti <- order(abs(Pave),decreasing = TRUE)
    sortval <- abs(Pave)[sorti]
    rankMatrix[sorti[which(sortval>0)],i] <- seq(1:length(which(sortval>0)))
    if(i==1){
      Puni <- Pave
    }else{
      Puni <- cbind(Puni,Pave)
    }
  }
  
  ave_result <- list(P=Puni,R=rankMatrix)
  return(ave_result)
  
}