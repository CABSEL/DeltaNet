function(X,y,options,kfold){
  cv <- cvFolds(length(y),K=kfold)
  cvi <- cv$which[order(cv$subsets)]
  #cvi <- rep(1:10,each=6)
  srange <- seq(0,1,1e-3)
  cvk <- matrix(nrow = kfold, ncol = length(srange))
  
  
  for(k in seq(1,kfold)){
    
    foldi <- which(cvi==k)
    foldni <- which(cvi!=k)
    kfit <- glmnet(X[foldni,],y[foldni],family="gaussian",alpha=options$alpha,lambda = options$lambda,
                   exclude = options$exclude,intercept = options$intr)
    beta <- as(kfit$beta,"matrix")
    t <- apply(abs(beta[1:(dim(beta)[1]-length(y)),]),2,sum)
    s <- t/max(t)
    b_interpolated <- interp1q(s,t(beta),srange)
    
    Xtest <- X[foldi,]
    ytest <- y[foldi]
    
    residual <- matrix(rep(ytest,length(srange)),ncol = length(srange))-Xtest%*%t(b_interpolated)
    cvk[k,] <- apply(residual^2,2,sum)/length(ytest)
  }
  
  
  cvm <- apply(cvk,2,mean)
  cvsd <- apply(cvk,2,sd)
  if(!anyNA(cvm)){
    minval <- min(cvm)
    opti1 <- which.min(cvm)
    opti2 <- min(which(cvm<minval+cvsd[opti1]))
  }else{
    cvm_new <- cvm
    cvm_new[which(is.na(cvm_new))] <- Inf
    minval <- min(cvm_new)
    opti1 <- which.min(cvm_new)
    opti2 <- min(which(cvm_new<minval+cvsd[opti1]))
  }
  sopt1 <- srange[opti1]
  sopt2 <- srange[opti2]
  
  
  
  fit <- glmnet(X,y,family="gaussian",alpha=options$alpha,lambda = options$lambda,
                exclude = options$exclude,intercept = options$intr)
  beta <- as(fit$beta,"matrix")
  t <- apply(abs(beta[1:(dim(beta)[1]-length(y)),]),2,sum)
  s <- t/max(t)
  b_opt <- interp1q(s,t(beta),c(sopt1,sopt2))
  
  if(sopt1==1){
    b_opt[1,] <- beta[,dim(beta)[2]]
  }
  
  
  if(sopt2==1){
    b_opt[2,] <- beta[,dim(beta)[2]]
  }
  
  result.b_tmin <- t(b_opt[1,])
  result.b_tlse <- t(b_opt[2,])
  result.sopt_min <- sopt1
  result.sopt_lse <- sopt2
  result.cvm <- cvm
  result.cvsd <- cvsd
  result.b_series <- beta
  result.tA <- t
  result <- list(b_tmin=result.b_tmin,b_tlse=result.b_tlse,sopt_min=result.sopt_min,
                 sopt_lse=result.sopt_lse,cvm=result.cvm,cvsd=result.cvsd,
                 b_series=result.b_series,tA=result.tA)
  return(result)
}
