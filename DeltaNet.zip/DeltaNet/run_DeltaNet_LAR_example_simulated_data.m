clc
clear all

%%% Load expression data (simulated data from GNW) 
DataFileName='Data_simulated_100genes_60samples';
DataFilePath='../DeltaNet/example_data/';
load(strcat(DataFilePath,DataFileName))

addpath('../DeltaNet/spasm') %% the path for SpaSM toolbox
LFC=Data.LFC; %% gene expression data matrix
replist=Data.replist; %% the list of replicate indices

%% DeltaNet-LAR
delta_r=0.01; %% Stopping criterion of DeltaNet-LAR. Recommended value is between 0.01 and 0.10.
numWorkers=1; %% The number of Workers for Matlab parallel computing
[rankMatrix,Puni,A]=deltanet_lar(LFC,delta_r,numWorkers,replist);

%% Disply gene rankings
TreatmentID = 1:20; %% (optional) Treatment indices for display. If empty, the results for all treatments will be displayed.
GeneList = Data.GList; %% (optional) the list of gene labels
TreatmentList = Data.TreatmentList(TreatmentID);%% (optional) the list of treatment labels
result_table = rankGenes(rankMatrix,Puni,TreatmentID,GeneList,TreatmentList); 