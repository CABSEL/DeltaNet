function Xc = center(X,dim)

rs=ones(1,2);
d=size(X);
rs(dim)=d(dim);
Xc=X-repmat(mean(X,dim),rs);