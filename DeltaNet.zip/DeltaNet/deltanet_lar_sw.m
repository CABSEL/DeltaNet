function Beta = deltanet_lar_sw(LFC,calGRange,delta_r,workerNum)
% A MATLAB subroutine to run DeltNet-LAR without parallelization. This subroutine is called by deltaNet_lar_par.m.
% Prerequisite: lar_dr()
% Usage: Beta = deltaNet_lar_sw(LFC, calGRange, delta_r)
% Arguments:
%   LFC: n x m log-2 fold-change gene expression data matrix. The dimensions n and m are the number of genes and samples respectively. 
%   calGRange: a row vector containing the indices of genes for which the perturbation scores will be computed.
%   delta_r: stopping criterion for LAR. Any value between 0 and 1 can be used, but we recommend a value between 0.01 and 0.1. 
% Output: 
%   Beta: LAR solution vectors


inputvar=inputParser;
addOptional(inputvar,'workernum',1,@(x) (x==round(x)) & (x>=1))

[N,M]=size(LFC);
Z=eye(M);
X=[LFC',Z];

% Input normalzation before least angle regression
[Xn,normvec]=standardize(X,1);
Cc=center(LFC,2);

temp=[];

Beta=[];
for gind=1:numel(calGRange)

    selG=calGRange(gind);
    y=Cc(selG,:)';
    
    % Setting the corresponding column of X for a gene as zero to make zero
    % diagonal entries in A matrix
    temp=Xn(:,selG);
    Xn(:,selG)=0;

    [btot,info]=lar_dr(Xn, y, -M, 1, 0, delta_r);% LAR algorithm (stopping criteiron delta_r was added in the LAR algorithm downloaded from SpaSm Matlab package, )
    Beta(:,gind)=diag(normvec)\btot(:,end);
    
    Xn(:,selG)=temp;
end
