clear all
clc

%%% Load expression data (E. coli compendium) 
DataFileName='Data_Ecoli_4217genes_524samples';
DataFilePath='../DeltaNet/example_data/';
load(strcat(DataFilePath,DataFileName))

addpath('../DeltaNet/glmnet_matlab') %% the path of GLMNET toolbox
lfc=Data.LFC; %% gene expression data matrix
replist=Data.replist; %% the list of replicate indices

%% DeltaNet-LASSO
kfold = 10; %% The number of folds in cross validation
numWorkers=2; %% The number of Workers for Matlab parallel computing
lambda=[]; %% use default lambda set 
[rankMatrix,Puni,A] = deltanet_lasso(lfc,lambda,kfold,numWorkers,replist);

%% Disply gene rankings
TreatmentID = 1:264; %% (optional) Treatment indices for display. If empty, the results for all treatments will be displayed.
GeneList = Data.GList; %% (optional) the list of gene labels
TreatmentList = Data.TreatmentList(TreatmentID);%% (optional) the list of treatment labels
result_table = rankGenes(rankMatrix,Puni,TreatmentID,GeneList,TreatmentList); 