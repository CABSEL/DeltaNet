function [rankMatrix,Puni,A] = deltanet_lasso(lfc,lambda,kfold,numWorkers,replist)
poolobj = gcp('nocreate');
delete(poolobj);

if nargin < 2 || isempty(lambda)
    lambda = 10.^linspace(-0.1,-5,100); %% A set of regularization parameters+
elseif length(lambda)<2
    error('More than one value of lambda is required for glmnet with CV.');
end

if nargin < 3 || isempty(kfold)
    kfold = 10; 
elseif mod(kfold,1)~=0 || kfold <5
    error('kfold should be a natural number more than 5.Default value is 10.');
end


if nargin < 4 || isempty(numWorkers) || numWorkers==1
    parswitch = 0; %% No parallel computing
elseif mod(numWorkers,1)==0 && numWorkers>1
    parpool('local',numWorkers)
    parswitch = 1; %% Use of parallel computing
elseif numWorkers > kfold
    error('NumWorkers should be smaller than or eqaul to kfold value.');
elseif numWorkers < 1
    error('NumWorkers should be greater than or eqaul to 1. If you do not want to use parallel computing, please set NumWorkers=1 or NumWorkers=[].');
elseif mod(numWorkers,1)~=0
    error('NumWorkers should be a natural number. If you do not want to use parallel computing, please set NumWorkers=1 or NumWorkers=[].');
end

if nargin < 5 || isempty(replist)
    replist=1:size(lfc,2);
elseif length(replist)~=size(lfc,2)
    error('The length of replist should be the same size as the number of samples (= the number of columns of LogFC data matrix.)');
end

[N,M]=size(lfc);
X = [lfc',eye(M)];
Y = lfc';

glmnet_options = [];
glmnet_options.intr=0; %% no fitting intercept
glmnet_options.alpha=1; %% LASSO implementation (no use of Elastic Net)
glmnet_options.lambda=lambda; %% A set of regularization parameters

beta=[];
grange=1:N;
srange = [0:1e-3:1];
fprintf('\n\nDeltaNet-LASSO is running...(   0/%d)\n',length(grange));
for gi = 1:length(grange)
    gs = grange(gi);
    fprintf('DeltaNet-LASSO is running...(%4d/%d)\n',gi,length(grange));
    
    y=Y(:,gs);
    glmnet_options.exclude = gs;
    result = crossvalidate_glmnet_betaA(X,y,glmnet_options,kfold,parswitch);
    beta=[beta,result.b_tmin];
    
end

A = beta(1:N,:)';
P = beta(N+1:end,:)';
Puni=[];
rankMatrix=length(grange)*ones(length(grange),max(replist));
for j=1:max(replist)
    ri = find(replist==j);
    Pave = median(P(:,ri),2);
    [sortval,sorti] = sort(abs(Pave),'descend');
    rankMatrix(sorti(sortval>0),j) = 1:nnz(sortval>0);
    Puni=[Puni,Pave];
end


fprintf('Calculation has been completed!\n');

if parswitch
    poolobj = gcp('nocreate');
    delete(poolobj)
end
