 function result = crossvalidate_glmnet_betaA(X,y,glmnet_options,kfold,parswitch)

% if nargin < 3
%     glmnet_options = [];
%     glmnet_options.intr=0; %% no fitting intercept
%     glmnet_options.alpha=1; %% LASSO implementation (no use of Elastic Net)
%     glmnet_options.lambda=10.^linspace(-0.1,-5,100); %% A set of regularization parameters
% end
% 
% if nargin < 4 || isempty(kfold)
%     kfold = 10;
% end

% if nargin < 5 || isempty(numWorkers) || numWorkers==1
%     poolobj = gcp('nocreate');
%     delete(poolobj);
%     parswitch = 0; %% No parallel computing
% elseif mod(numWorkers,1)==0 && numWorkers>1
%     parpool('local',numWorkers)
%     parswitch = 1; %% Use of parallel computing
% elseif numWorkers < 1
%     error('NumWorkers should be greater than or eqaul to 1. If you do not want to use parallel computing, please set NumWorkers=1 or NumWorkers=[].');
% elseif mod(numWorkers,1)~=0
%     error('NumWorkers should be a natural number. If you do not want to use parallel computing, please set NumWorkers=1 or NumWorkers=[].');
% end

glmnet_options = glmnetSet(glmnet_options);

if (~isempty(glmnet_options.lambda)) && (length(glmnet_options.lambda)<2)
    error('More than one value of lambda is required for glmnet with CV.');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%% Cross Validation %%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
cvi = crossvalind('Kfold',length(y),kfold);
srange = [0:1e-3:1];
cvk=[];

if parswitch
    opts(1:kfold) = {glmnet_options};
    
    kfit=cell(10,1);
    parfor k=1:kfold
        foldi = (cvi==k);
        kfit{k} = glmnet(X(~foldi,:),y(~foldi),[],opts{k});
    end
    
    for k=1:kfold
        foldi = (cvi==k);
        t = sum(abs(kfit{k}.beta(1:end-length(y),:)),1); %% t = L1-norm of coefficients in network A for a corresponding gene
        s = t/max(t);
        b_interpolated=interp1q(s',kfit{k}.beta',srange');
        
        Xtest = X(foldi,:);
        ytest = y(foldi);
        
        residual = repmat(ytest,[1,length(srange)])-Xtest*b_interpolated';
        cvk(k,:)=sum(residual.^2,1)/nnz(foldi);
    end
    
else
    opts = glmnet_options;
    for k=1:kfold
        foldi = (cvi==k); 
        kfit=glmnet(X(~foldi,:), y(~foldi),[],opts); 
        t = sum(abs(kfit.beta(1:end-length(y),:)),1); %% t = L1-norm of coefficients in network A for a corresponding gene
        s = t/max(t);
        b_interpolated=interp1q(s',kfit.beta',srange');
        
        Xtest = X(foldi,:);
        ytest = y(foldi);
        
        residual = repmat(ytest,[1,length(srange)])-Xtest*b_interpolated';
        cvk(k,:)=sum(residual.^2,1)/nnz(cvi==k);
    end
end

cvm = mean(cvk,1);
cvsd = std(cvk,[],1);
[minval,opti1] = min(cvm); %% t giving the minimum CV error
opti2 = find(cvm < minval+cvsd(opti1),1,'first'); %% one-standard error rule

sopt1 = srange(opti1);
sopt2 = srange(opti2);


%%%%%%%%%%%%%%%%%%% GLMNET-LASSO solution with optimal t %%%%%%%%%%%%%%%%%%
fit=glmnet(X, y,[],glmnet_options);
t = sum(abs(fit.beta(1:end-length(y),:)),1); %% t =||Ba||1
s = t/max(t);
b_opt=interp1q(s',fit.beta',[sopt1;sopt2]);

tend_ind=ismember([sopt1,sopt2],1);
b_opt(tend_ind,:)=repmat(fit.beta(:,end)',[nnz(tend_ind),1]);

result.b_tmin = b_opt(1,:)';
result.b_t1se = b_opt(2,:)';
result.sopt_min = sopt1;
result.sopt_1se = sopt2;
result.cvm = cvm;
result.cvsd = cvsd;
result.b_series = fit.beta;
result.tA = t;