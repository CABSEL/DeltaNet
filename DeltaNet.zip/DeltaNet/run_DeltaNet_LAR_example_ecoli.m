clc
clear all

%%% Load expression data (E. coli compendium) 
DataFileName='Data_Ecoli_4217genes_524samples';
DataFilePath='../DeltaNet/example_data/';
load(strcat(DataFilePath,DataFileName))

addpath('../DeltaNet/spasm') %% the path of SpaSM toolbox accordingly.
LFC=Data.LFC; %% gene expression data matrix
replist=Data.replist; %% the list of replicate indices

%% DeltaNet-LAR
delta_r=0.01; %% Stopping criterion of DeltaNet-LAR. Recommended value is between 0.01 and 0.10
numWorkers=2; %% The number of Workers for Matlab parallel computing
[rankMatrix,Puni,A]=deltanet_lar(LFC,delta_r,numWorkers,replist);

%% Disply gene rankings
TreatmentID = 1:264; %% (optional) Treatment indices for display. If empty, the results for all treatments will be displayed.
GeneList = Data.GList; %% (optional) the list of gene labels
TreatmentList = Data.TreatmentList(TreatmentID);%% (optional) the list of treatment labels
result_table = rankGenes(rankMatrix,Puni,TreatmentID,GeneList,TreatmentList);
