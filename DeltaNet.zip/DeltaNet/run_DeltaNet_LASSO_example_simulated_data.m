clear all
clc
 
%%% Load expression data (simulated by GNW) 
DataFileName='Data_simulated_100genes_90samples';
DataFilePath='../DeltaNet/example_data/';
load(strcat(DataFilePath,DataFileName,'.mat'))
 
addpath('../DeltaNet/glmnet_matlab') %% Pthe folder path of GLMNET 
lfc=Data.LFC; %% gene expression data matrix
replist=Data.replist; %% the list of replicate indices

%% DeltaNet-LASSO
kfold = 10; %% The number of folds in cross validation
numWorkers=1; %% The number of workers for Matlab parallel computing.
lambda=[];  
 
[rankMatrix,Puni,A] = deltanet_lasso(lfc,lambda,kfold,numWorkers,replist);
 
%% Disply gene rankings
TreatmentID = 1:30; %% (optional) Treatment indices for display. If empty, the results for all conditions will be displayed.
GeneList = Data.GList; %% (optional) the list of gene labels
TreatmentList = Data.TreatmentList(TreatmentID);%% (optional) the list of treatment labels
result_table = rankGenes(rankMatrix,Puni,TreatmentID,GeneList,TreatmentList);