function [rankMatrix,Puni,A]=deltanet_lar(lfc,delta_r,numWorkers,replist)
poolobj = gcp('nocreate');
delete(poolobj);
    
if nargin < 2 || isempty(delta_r)
    delta_r = 0.10 %% default value
elseif (delta_r < 0) || (delta_r >=1)
    error('delta_r should be in the range of [0 1].');
end

if nargin < 3 || isempty(numWorkers) || numWorkers==1
    parswitch = 0; %% No parallel computing
elseif mod(numWorkers,1)==0 && numWorkers>1
    parpool('local',numWorkers)
    parswitch = 1; %% Use of parallel computing
elseif numWorkers < 1
    error('NumWorkers should be greater than or eqaul to 1. If you do not want to use parallel computing, please set NumWorkers=1 or NumWorkers=[].');
elseif mod(numWorkers,1)~=0
    error('NumWorkers should be a natural number. If you do not want to use parallel computing, please set NumWorkers=1 or NumWorkers=[].');
end

if nargin < 4 || isempty(replist)
    replist=1:size(lfc,2);
elseif length(replist)~=size(lfc,2)
    error('The length of replist should be the same size as the number of samples (= the number of columns of LogFC data matrix.)');
end

[N,M]=size(lfc);
grange=1:N;
fprintf('\n\nDeltaNet-LAR is running...\n',length(grange));

if parswitch
    %%% Partitioning gene indices for parellel computation
    g_group=sort(crossvalind('Kfold',length(grange),numWorkers));

    %%% Running DeltaNet-LAR in parallel
    B={};
    parfor ci=1:numWorkers
        gi=grange(g_group==ci);
        Beta = deltanet_lar_sw(lfc,gi,delta_r,ci);
        B{ci}=Beta;
    end
    
    % Combine P from computated P in Parallel
    BETAtot=[];
    for j=1:numel(B)
        BETAtot=[BETAtot,B{j}];
    end
    
else
    gi=grange;
    BETAtot = deltanet_lar_sw(lfc,gi,delta_r);
end

A = BETAtot(1:N,:)';
P = BETAtot(N+1:end,:)';

Puni=[];
rankMatrix=length(grange)*ones(length(grange),max(replist));
for j=1:max(replist)
    ri = find(replist==j);
    Pave = median(P(:,ri),2);
    [sortval,sorti] = sort(abs(Pave),'descend');
    rankMatrix(sorti(sortval>0),j) = 1:nnz(sortval>0);
    Puni=[Puni,Pave];
end

fprintf('Calculation has been completed!\n');

if parswitch
    poolobj = gcp('nocreate');
    delete(poolobj)
end
