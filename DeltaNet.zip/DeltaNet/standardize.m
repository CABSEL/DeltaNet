function [Xn normvec] = standardize(X,dim)

Xc=center(X,dim);

rs=ones(1,2);
d=size(X);
rs(dim)=d(dim);

normvec=sqrt(sum(Xc.^2,dim));
normvec(normvec==0)=1;
Xn = Xc./repmat(normvec,rs);